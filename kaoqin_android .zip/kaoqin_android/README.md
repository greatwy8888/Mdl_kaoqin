# 考勤 Android App

这是一个按用户提供的“排班考勤日历”截图制作的 Android Studio 项目，应用名称为 **考勤**。

## 已实现
- 2024—2033 共10年日历，可下拉选择年份和月份。
- 上一月 / 下一月 / 回到本月。
- 周一至周五、周日默认“正常”；周六默认“休息”。
- 点击任意日期编辑内容。
- 输入“正常”显示黑色；输入“休息”显示红色；也可以输入其他备注。
- “恢复默认”会删除该日期的自定义内容，重新按星期自动排班。
- 使用 Android 本地 WebView + localStorage 保存数据，关闭 App 后备注仍保留。
- 手机竖屏界面，尽量贴近用户提供的参考图。

## 编译 APK
需要 Android Studio（推荐最新版）和 Android SDK 35。

1. 用 Android Studio 打开本目录。
2. 等待 Gradle 同步。
3. 选择 `app` -> `assembleDebug`，或 Build -> Build APK(s)。
4. Debug APK 输出在 `app/build/outputs/apk/debug/app-debug.apk`。

### GitHub Actions
项目附带 `.github/workflows/build-apk.yml`。把整个项目上传到 GitHub 后，在 Actions 中运行 **Build Android APK**，可自动编译 APK 并上传为构建产物。
